package com.mycompany.agiliza;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** Regras do cadastro e do login. */
public class UsuarioService {

    public Usuario cadastrar(String nome, String email, String senha) {
        if (nome == null || nome.trim().length() < 2) {
            throw new IllegalArgumentException("Informe seu nome");
        }
        if (email == null || !email.trim().matches("^\\S+@\\S+\\.\\S+$")) {
            throw new IllegalArgumentException("E-mail inválido");
        }
        if (senha == null || senha.length() < 8) {
            throw new IllegalArgumentException("Use pelo menos 8 caracteres");
        }

        email = email.trim().toLowerCase();
        if (buscarPorEmail(email) != null) {
            throw new IllegalArgumentException("Este e-mail já está cadastrado");
        }

        Usuario novo = new Usuario(null, nome.trim(), email, SenhaHasher.gerar(senha));
        return salvar(novo);
    }

    /** Devolve o usuário se e-mail e senha estiverem certos, ou null se não estiverem. */
    public Usuario autenticar(String email, String senha) {
        if (email == null || senha == null) {
            return null;
        }
        Usuario u = buscarPorEmail(email.trim().toLowerCase());
        if (u != null && SenhaHasher.conferir(senha, u.getSenha())) {
            return u;
        }
        return null; // mesma resposta para e-mail inexistente e senha errada
    }

    // ============ ÚNICOS PONTOS QUE DEPENDEM DO BANCO ============

    // Devolve o Usuario (id, nome, email e hash da senha) ou null se não existir.
    private Usuario buscarPorEmail(String email) {
        String sql = "SELECT id_usuario, nome, email, senha FROM usuario WHERE email = ?";
        try (Connection con = Conexao.abrir();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(rs.getLong("id_usuario"), rs.getString("nome"),
                                       rs.getString("email"), rs.getString("senha"));
                }
                return null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao buscar usuário", e);
        }
    }

    // Salva no banco e devolve o Usuario já com o id gerado.
    private Usuario salvar(Usuario usuario) {
        String sql = "INSERT INTO usuario (nome, email, senha) VALUES (?, ?, ?)";
        try (Connection con = Conexao.abrir();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getSenha());
            ps.executeUpdate();
            try (ResultSet chaves = ps.getGeneratedKeys()) {
                chaves.next();
                return new Usuario(chaves.getLong(1), usuario.getNome(),
                                   usuario.getEmail(), usuario.getSenha());
            }
        } catch (SQLException e) {
            throw new RuntimeException("Erro ao salvar usuário", e);
        }
    }
}
