package com.mycompany.agiliza;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Abre a conexão com o SQL Server. Só aqui você mexe se mudar o banco ou a senha. */
public class Conexao {
    // Se usar "Autenticação do Windows" em vez de usuário/senha, me avise que eu ajusto.
    private static final String URL =
        "jdbc:sqlserver://localhost:1433;databaseName=agiliza;encrypt=false;trustServerCertificate=true";
    private static final String USUARIO = "sa";
    private static final String SENHA = "joaohalves";

    public static Connection abrir() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
}
