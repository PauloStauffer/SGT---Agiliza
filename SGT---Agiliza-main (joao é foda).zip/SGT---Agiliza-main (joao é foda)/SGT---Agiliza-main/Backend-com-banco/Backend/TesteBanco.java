package com.mycompany.agiliza;

/** Roda isto para conferir se o banco está funcionando. */
public class TesteBanco {
    public static void main(String[] args) {
        UsuarioService service = new UsuarioService();
        String email = "teste" + System.currentTimeMillis() + "@agiliza.com";

        Usuario u = service.cadastrar("Joao Teste", email, "senha12345");
        System.out.println("Cadastrou com id " + u.getId_usuario());

        System.out.println("Login certo:  " + (service.autenticar(email, "senha12345") != null));
        System.out.println("Login errado: " + (service.autenticar(email, "outrasenha") != null));

        try {
            service.cadastrar("Joao Teste", email, "senha12345");
        } catch (IllegalArgumentException e) {
            System.out.println("Email repetido bloqueado: " + e.getMessage());
        }
    }
}
